arquivo_escrita = open("dados_write2.txt", "w")
arquivo_escrita.write("Conteúdo da primeira linha.")
arquivo_escrita.write("\nConteúdo da segunda linha.")
arquivo_escrita.close()
