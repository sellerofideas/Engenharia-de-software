import os

os.rename("inicio.txt", "final.txt")
