arquivo = open("exercicio_1.txt", "w")
arquivo.write("\nTeste 3")
arquivo.write("\nTeste 4")
arquivo.close()

arquivo = open("exercicio_1.txt", "a")
arquivo.write("\nTeste 5")
arquivo.write("\nTeste 6")
arquivo.close()

arquivo = open("exercicio_1.txt", "w")
arquivo.write("\nTeste 7")
arquivo.write("\nTeste 8")
arquivo.close()
