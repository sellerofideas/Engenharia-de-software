frase = "Eu amo comer amoras no café da manhã"

lista_termos = frase.split()
print("Contagem simplificada: ", lista_termos.count('amo'))
