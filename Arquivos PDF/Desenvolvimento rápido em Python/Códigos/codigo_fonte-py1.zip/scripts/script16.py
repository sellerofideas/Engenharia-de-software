frase1 = "Eu amo comer amoras no café da manhã"
lista_termos1 = frase1.split()
print(lista_termos1)

frase2 = "Amora  abacaxi    abacate     banana"
lista_termos2 = frase2.split()
print(lista_termos2)

frase3 = "Carro,moto,avião"
lista_termos3 = frase3.split(',')
print(lista_termos3)
