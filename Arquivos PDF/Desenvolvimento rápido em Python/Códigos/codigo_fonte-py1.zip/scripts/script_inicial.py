arquivo = open("teste.txt")

print("Arquivo aberto com sucesso!")
