import os

os.rmdir("diretorio")
