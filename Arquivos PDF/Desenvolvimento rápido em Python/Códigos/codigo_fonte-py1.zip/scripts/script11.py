arquivo_escrita = open("dados_write.txt", "a")

arquivo_escrita.write("\nConteúdo adicional.")

arquivo_escrita.close()
